sap.ui.define([
  "./BaseController"
], (BaseController) => {
  "use strict";

  return BaseController.extend("sapp.galactic.spacefare.controller.App", {
    onInit() {
    }
  });
});