sap.ui.define(["./BaseController"],e=>{"use strict";return e.extend("sapp.galactic.spacefare.controller.App",{onInit(){}})});
//# sourceMappingURL=App.controller.js.map